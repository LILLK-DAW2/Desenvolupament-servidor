<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;

class PokemonsSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        // Tipos disponibles para los pokemons
        $tipos = ['eléctrico', 'bicho', 'fuego', 'agua', 'planta', 'roca', 'hielo', 'veneno', 'volador', 'normal'];

        // Generar 15 pokemons
        for ($i = 1; $i <= 15; $i++) {
            DB::table('pokemons')->insert([
                'nombre' => 'Pokemon' . $i,
                'tipo' => $tipos[rand(0, 9)],
                'nivel' => rand(1, 100),
                'descripcion' => 'Descripción del Pokemon' . $i,
                'stock' => rand(0, 50),
                'precio' => rand(10, 100) / 10.0,
                'created_at' => now(),
                'updated_at' => now(),
            ]);
        }
    }
}
