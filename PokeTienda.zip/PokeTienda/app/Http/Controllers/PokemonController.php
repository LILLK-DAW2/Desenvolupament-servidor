<?php

namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;

class PokemonController extends Controller
{
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $pokemons = Pokemon::all();
        return view('Pokemons')->with('pokemons', $pokemons);
    }
    public function create()
    {
        return view('pokemons');
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {


        $this->validate($request, [
            'nombre' => 'required',
            'descripcion' => 'required',
            'tipo' => 'required|in:eléctrico, bicho, fuego agua planta roca hielo veneno volador, normal' ,
        ]);
        Pokemon::create($request->all());
        return redirect()->route('indexPokemon')->with('successStore','Pokemon creado correctamente');
    }

    /**
     * Display the specified resource.
     */
    public function show()
    {
        // Aquí, realiza la lógica necesaria para obtener los datos que deseas mostrar
        $pokemons = Pokemon::all();

        // Luego, retorna la vista con los datos necesarios
        return view('pokemons')->with('pokemons', $pokemons);
    }



    /**
     * Remove the specified resource from storage.
     */
    public function destroy(Request $request)
    {
        $idSolicitado = $request->input('idSolicitado');

        try {
            $pokemon = Pokemon::findOrFail($idSolicitado);
            $pokemon->delete();

            return redirect()->route('indexPokemon')->with('successDestroy', 'Pokemon eliminado correctamente');
        } catch (\Exception $e) {
            //dd($e->getMessage());
            return redirect()->route('indexPokemon')->with('errorDestroy', 'Error al intentar eliminar el Pokémon');
        }
    }

    public function edit($id)
    {
        $pokemon = Pokemon::findOrFail($id);
        return view('editPokemon')->with('pokemon', $pokemon);
    }

    public function update(Request $request)

    {
        $id = $request->input('id');
        $pokemon = Pokemon::findOrFail($id);

        $this->validate($request, [
            'nombre' => 'required',
            'descripcion' => 'required',
            'tipo' => 'required|in:eléctrico, bicho, fuego agua planta roca hielo veneno volador, normal' ,
        ]);

        $pokemon->update($request->all());

        return redirect()->route('verPokemon')->with('successUpdate', 'Pokemon actualizado correctamente');
    }
}
