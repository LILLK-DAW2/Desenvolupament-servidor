<?php
header("Location: views/menu.html");
?>
