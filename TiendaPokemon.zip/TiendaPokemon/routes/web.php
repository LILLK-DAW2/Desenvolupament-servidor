<?php

use App\Http\Controllers\PerfilController;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\log\RegAuth;
use App\Http\Controllers\log\LoginAuth;
use App\Http\Controllers\PokemonController;
use App\Http\Controllers\UsersController;
use App\Http\Controllers\CarritoController;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

//Ruta principal
Route::get('/', function () {
    return view('log.login');
});

//Ruta log
Route::view('/log','log.login')->name('verLog');
Route::post('/log/logged', [LoginAuth::class, 'login'])->name('logged');
Route::get('/log/logout', [LoginAuth::class, 'logout'])->name('logout');

//Ruta reg
Route::view('/reg','log.register')->name('verReg');
Route::post('/reg/register', [RegAuth::class, 'register'])->name('register');

//Ruta home
Route::view('/home','home')->name('verHome');

//Ruta Perfil
Route::get('/perfil',[PerfilController::class, 'index'])->name('verPerfil');
Route::post('/perfil/update', [PerfilController::class, 'update'])->name('updatePerfil');

//Ruta Pokemons
Route::view('/pokemons','Tienda.pokemons');
Route::get('/pokemons',[PokemonController::class, 'index'])->name('verPokemons');
Route::get('/pokemons/{id}',[PokemonController::class, 'edit'])->name('editarPokemon')->middleware('rol');
Route::post('/pokemons/storePokemon',[PokemonController::class, 'store'])->name('storePokemon')->middleware('rol');
Route::delete('/pokemons',[PokemonController::class, 'destroy'])->name('destroyPokemon')->middleware('rol');
Route::get('/pokemons/edit/{id}', [PokemonController::class, 'edit'])->name('editPokemon')->middleware('rol');
Route::post('/pokemons/update', [PokemonController::class, 'update'])->name('updatePokemon')->middleware('rol');

//Ruta Users
Route::view('/users','Users.users')->middleware('rol');
Route::get('/users',[UsersController::class, 'index'])->name('verUsers')->middleware('rol');
Route::get('/users/{id}',[UsersController::class, 'edit'])->name('editarUser')->middleware('rol');
Route::post('/users/storeUser',[UsersController::class, 'store'])->name('storeUser')->middleware('rol');
Route::delete('/users',[UsersController::class, 'destroy'])->name('destroyUser')->middleware('rol');
Route::get('/users/edit/{id}', [UsersController::class, 'edit'])->name('editUser')->middleware('rol');
Route::post('/users/update', [UsersController::class, 'update'])->name('updateUser')->middleware('rol');

//Ruta carritos
Route::view('/carrito','Carrito.carrito');
Route::get('/carrito/add',[CarritoController::class, 'agregar'])->name('addCarrito');
Route::get('/carrito/rest',[CarritoController::class, 'retirar'])->name('restCarrito');
Route::get('/carrito',[CarritoController::class, 'index'])->name('verCarrito');
Route::post('/carrito/storecarrito',[CarritoController::class, 'store'])->name('storeCarrito')->middleware('rol');
Route::delete('/carrito',[CarritoController::class, 'destroy'])->name('destroyCarrito')->middleware('rol');
Route::get('/carrito/edit/{id}', [CarritoController::class, 'edit'])->name('editCarrito')->middleware('rol');
Route::post('/carrito/update', [CarritoController::class, 'update'])->name('updateCarrito')->middleware('rol');




