<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<!-- Nav bar-->
<div>

    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verCarrito')); ?>">Carrito<span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verPerfil')); ?>" >Perfil<span class="sr-only">(current)</span></a>
                </li>
                <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>

                    <li class="nav-item active">
                        <a class="nav-link link-warning" href="<?php echo e(route('verUsers')); ?>">Usuarios <span class="sr-only">(current)</span></a>
                    </li>
                <?php endif; ?>

                <li class="nav-item active">
                    <a class="btn btn-warning"  href="<?php echo e(route('logout')); ?>">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Vista de la tabla-->
<div class="container mt-4">
    <?php if(session('succes')): ?>
            <h6 class="alert alert-success"> <?php echo e(session('succes')); ?> </h6>
    <?php elseif(session('error')): ?>
            <h6 class="alert alert-danger"> <?php echo e(session('error')); ?> </h6>
    <?php endif; ?>
    <?php if(session('successUpdate')): ?>
        <div>
            <h6 class="alert alert-success"> <?php echo e(session('successUpdate')); ?> </h6>
        </div>
    <?php endif; ?>
    <section class="container ver_pokemons">
        <table class="mt-4 table table-striped table-dark">
            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nombre</th>
                <th scope="col">Tipo</th>
                <th scope="col">Nivel</th>
                <th scope="col">Descripcion</th>
                <th scope="col">Stock</th>
                <th scope="col">Precio</th>

            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($pokemon->id); ?></th>
                    <td><?php echo e($pokemon->nombre); ?></td>
                    <td><?php echo e($pokemon->tipo); ?></td>
                    <td><?php echo e($pokemon->nivel); ?></td>
                    <td><?php echo e($pokemon->descripcion); ?></td>
                    <td><?php echo e($pokemon->stock); ?></td>
                    <td><?php echo e($pokemon->precio); ?> $</td>
                    <td>
                        <a href="<?php echo e(route('addCarrito',['id_pokemon' => $pokemon->id])); ?>" class="btn btn-warning"><i class="bi bi-plus">+</i></a>
                        <a href="<?php echo e(route('restCarrito',['id_pokemon' => $pokemon->id])); ?>" class="btn btn-warning"><i class="bi bi-dash"> - </i></a>
                        <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>
                            <a href="<?php echo e(route('editPokemon' , ['id' => $pokemon->id])); ?>" class="btn btn-warning"><i class="bi bi-dash">Editar</i></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    <br>
    <!-- Añadir en la tabla-->
    <section class="container">
        <h1>Añadir pokemons</h1>
        <div>
            <?php if(session('successStore')): ?>
                <div>
                    <h6 class="alert alert-success"> <?php echo e(session('successStore')); ?> </h6>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><h6 class="alert alert-danger"> <?php echo e($error); ?> </h6></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('storePokemon')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" name="nombre" placeholder="Nombre" value="<?php echo e(old('nombre')); ?>">
            </div>
            <div class="form-group">
                <label for="tipo">Tipo</label>
                <select class="form-control" name="tipo">
                    <?php $__currentLoopData = ['eléctrico', 'bicho', 'fuego', 'agua', 'planta', 'roca', 'hielo', 'veneno', 'volador']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($option); ?>" <?php echo e(old('tipo') === $option ? 'selected' : ''); ?>>
                            <?php echo e(ucfirst($option)); ?>

                        </option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="nivel">Nivel</label>
                <input type="number" class="form-control" name="nivel" placeholder="Nivel" value="<?php echo e(old('nivel')); ?>">
            </div>
            <div class="form-group">
                <label for="descripcion">Descripcion</label>
                <input type="text" class="form-control" name="descripcion" placeholder="descripcion" value="<?php echo e(old('descripcion')); ?>">
            </div>
            <div class="form-group">
                <label for="stock">Stock</label>
                <input type="number" class="form-control" name="stock" placeholder="stock" value="<?php echo e(old('stock')); ?>">
            </div>
            <div class="form-group">
                <label for="precio">Precio</label>
                <input type="number" class="form-control" name="precio" placeholder="precio" value="<?php echo e(old('precio')); ?>">
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>


    </section>
    <br>
    <!-- Borrar tabla-->
    <section class="container borrar_pokemons">
        <h1>Borrar pokemons</h1>

        <?php if(session('successDestroy')): ?>
            <div class="alert alert-success">
                <?php echo e(session('successDestroy')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('errorDestroy')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('errorDestroy')); ?>

            </div>
        <?php endif; ?>

        <form method="POST"  action="<?php echo e(route('destroyPokemon')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="form-group">
                <label for="idSolicitado">ID a Borrar:</label>
                <input type="text" name="idSolicitado" class="form-control" placeholder="Ingrese el ID">
            </div>
            <button type="submit" class="btn btn-danger">Borrar</button>
        </form>
    </section>
</div>
</body>
</html>
<?php /**PATH D:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/Tienda/pokemons.blade.php ENDPATH**/ ?>