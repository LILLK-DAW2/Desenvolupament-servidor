<script>
    function confirmLogout() {
        if (window.confirm("¿Estás seguro de que quieres salir?")) {
           console.log("Logout confirmado, redirigiendo...");
           window.location.href = "<?php echo e(route('logout')); ?>";
        } else {
            console.log("Logout cancelado.");
        }
    }
</script>

<div>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="/pokemons">Tienda<span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verCarrito')); ?>">Carrito<span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verPerfil')); ?>" >Perfil<span class="sr-only">(current)</span></a>
                </li>
                <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>

                <li class="nav-item active">
                    <a class="nav-link link-warning" href="<?php echo e(route('verUsers')); ?>">Usuarios <span class="sr-only">(current)</span></a>
                </li>
                <?php endif; ?>
                <li class="nav-item active">
                    <a class="btn btn-warning"    onclick="confirmLogout()">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
</div>
<div class="container">
    <?php if(session('LogSuccess')): ?>
        <div class="alert alert-success">
            <?php echo e(session('LogSuccess')); ?>

        </div>
    <?php endif; ?>
        <?php if(session('Permisos')): ?>
            <div>
                <h6 class="alert alert-danger"> <?php echo e(session('Permisos')); ?> </h6>
            </div>
        <?php endif; ?>
    <h1>hola: <?php echo e(Auth::user()->nick); ?></h1>
</div>
<?php /**PATH D:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/home.blade.php ENDPATH**/ ?>