
<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<div>
    <nav class="navbar fixed-top navbar-light bg-light">
        <a class="btn btn-warning col-1 container" href="<?php echo e(route('verPokemons')); ?> " >Volver</a>
    </nav>
</div>
<section class="container ">
    <h1>Editar Pokemon</h1>
    <form action="<?php echo e(route('updatePokemon')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo method_field('POST'); ?>
        <!-- Campo no editable para el ID -->
        <div class="form-group">
            <label for="id">ID</label>
            <input type="text" class="form-control" name="id" value="<?php echo e($pokemon->id); ?>" readonly>
        </div>

        <div class="form-group">
            <label for="nombre">Nombre</label>
            <input type="text" class="form-control" name="nombre" placeholder="Nombre" value="<?php echo e($pokemon->nombre); ?>">
        </div>
        <div class="form-group">
            <label for="tipo">Tipo</label>
            <select class="form-control" name="tipo">
                <?php $__currentLoopData = ['eléctrico', 'bicho', 'fuego', 'agua', 'planta', 'roca', 'hielo', 'veneno', 'volador']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($option); ?>" <?php echo e($pokemon->tipo === $option ? 'selected' : ''); ?>>
                        <?php echo e(ucfirst($option)); ?>

                    </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="nivel">Nivel</label>
            <input type="number" class="form-control" name="nivel" placeholder="Nivel" value="<?php echo e($pokemon->nivel); ?>">
        </div>
        <div class="form-group">
            <label for="descripcion">Descripcion</label>
            <input type="text" class="form-control" name="descripcion" placeholder="Descripcion" value="<?php echo e($pokemon->descripcion); ?>">
        </div>
        <div class="form-group">
            <label for="stock">Stock</label>
            <input type="number" class="form-control" name="stock" placeholder="Stock" value="<?php echo e($pokemon->stock); ?>">
        </div>
        <div class="form-group">
            <label for="precio">Precio</label>
            <input type="number" class="form-control" name="precio" placeholder="Precio" value="<?php echo e($pokemon->precio); ?>">
        </div>
        <button type="submit" class="btn btn-primary">Guardar cambios</button>
    </form>
</section></body>
</html>
<?php /**PATH D:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/Tienda/pokemonsEdit.blade.php ENDPATH**/ ?>