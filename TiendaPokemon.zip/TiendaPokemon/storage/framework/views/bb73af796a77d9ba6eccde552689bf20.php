<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Carrito</title>
</head>
<body>
<!-- Navbar -->
<div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verPokemons')); ?>">Tienda<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verPerfil')); ?>">Perfil<span class="sr-only">(current)</span></a>
                </li>
                <?php if(Auth::check() && Auth::user()->rol == 'admin'): ?>
                    <li class="nav-item active">
                        <a class="nav-link link-warning" href="<?php echo e(route('verUsers')); ?>">Usuarios<span class="sr-only">(current)</span></a>
                    </li>
                <?php endif; ?>
                <li class="nav-item active">
                    <a class="btn btn-warning" href="<?php echo e(route('logout')); ?>">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Vista de la tabla carrito -->
<div class="container mt-4">
    <section class="container ver_carrito">
        <?php if(session('succes')): ?>
            <h6 class="alert alert-success"> <?php echo e(session('succes')); ?> </h6>
        <?php elseif(session('error')): ?>
            <h6 class="alert alert-danger"> <?php echo e(session('error')); ?> </h6>
        <?php endif; ?>
        <?php if(session('successUpdate')): ?>
            <div>
                <h6 class="alert alert-success"> <?php echo e(session('successUpdate')); ?> </h6>
            </div>
        <?php endif; ?>
        <table class="mt-4 table table-striped table-dark">
            <thead>
            <tr>
                <th scope="col">#</th>
                <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>
                    <th scope="col">Usuario</th>
                <?php endif; ?>
                <th scope="col">Pokemon</th>
                <th scope="col">Cantidad</th>
                <th scope="col">Precio Total</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $carrito; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($item->id); ?></th>
                    <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>
                        <td><?php echo e($item->user->nombre); ?></td>
                    <?php endif; ?>
                    <td><?php echo e($item->pokemon->nombre); ?></td>
                    <td><?php echo e($item->cantidad); ?></td>
                    <td><?php echo e($item->precio); ?> $</td>
                    <td>
                        <a href="<?php echo e(route('addCarrito',['id_pokemon' => $item->pokemon->id ,'id_user' => $item->user->dni])); ?>" class="btn btn-warning"><i class="bi bi-plus">+</i></a>
                        <a href="<?php echo e(route('restCarrito',['id_pokemon' => $item->pokemon->id , 'id_user' => $item->user->dni])); ?>" class="btn btn-warning"><i class="bi bi-dash"> - </i></a>
                        <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>
                            <a href="<?php echo e(route('editCarrito' , ['id' => $item->id])); ?>" class="btn btn-warning"><i class="bi bi-dash">Editar</i></a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    <br>
    <!-- Añadir al carrito -->
    <section class="container">
        <h1>Añadir al carrito</h1>
        <?php if(session('succes')): ?>
            <div>
                <h6 class="alert alert-success"> <?php echo e(session('succes')); ?> </h6>
            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <div class="alert alert-danger">
                <ul>
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><h6 class="alert alert-danger"> <?php echo e($error); ?> </h6></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        <?php endif; ?>
        <form action="<?php echo e(route('storeCarrito')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="id_user">Usuario:</label>
                <select name="id_user" class="form-control">
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($user->dni); ?>"><?php echo e($user->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>
            <div class="form-group">
                <label for="id_pokemon">Selecciona un Pokémon:</label>
                <select name="id_pokemon" class="form-control">
                    <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($pokemon->id); ?>"><?php echo e($pokemon->nombre); ?></option>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </select>
            </div>

            <div class="form-group">
                <label for="cantidad">Cantidad:</label>
                <input type="number" name="cantidad" class="form-control" placeholder="cantidad">
            </div>
            <div class="form-group">
                <label for="precio">Precio:</label>
                <input type="text" name="precio" class="form-control" placeholder="precio">
            </div>
            <button type="submit" class="btn btn-primary">Añadir al carrito</button>
        </form>
    </section>
    <br>
    <!-- Borrar del carrito -->
    <section class="container borrar_carrito">
        <h1>Borrar del carrito</h1>
        <?php if(session('succesDestroy')): ?>
            <div class="alert alert-success">
                <?php echo e(session('succesDestroy')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('errorDestroy')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('errorDestroy')); ?>

            </div>
        <?php endif; ?>
        <form method="POST" action="<?php echo e(route('destroyCarrito')); ?>">
            <?php echo csrf_field(); ?>
            <?php echo method_field('delete'); ?>
            <div class="form-group">
                <label for="idSolicitado">ID del Pokémon en el carrito:</label>
                <input type="text" name="idSolicitado" class="form-control" placeholder="Ingrese el ID">
            </div>
            <button type="submit" class="btn btn-danger">Borrar del carrito</button>
        </form>
    </section>
</div>
</body>
</html>
<?php /**PATH G:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/Carrito/carrito.blade.php ENDPATH**/ ?>