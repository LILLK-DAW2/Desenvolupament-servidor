<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Document</title>
</head>
<body>
<!-- Nav bar-->
<div>

    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/pokemons">Tienda<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verCarrito')); ?>">Carrito<span class="sr-only">(current)</span></a>
                </li>


                <li class="nav-item active">
                    <a class="nav-link" href="<?php echo e(route('verPerfil')); ?>" >Perfil<span class="sr-only">(current)</span></a>
                </li>


                <li class="nav-item active">
                    <a class="btn btn-warning"  href="<?php echo e(route('logout')); ?>">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Vista de la tabla-->
<div class="container mt-4">
    <?php if(session('successUpdate')): ?>
        <div>
            <h6 class="alert alert-success"> <?php echo e(session('successUpdate')); ?> </h6>
        </div>
    <?php endif; ?>
    <section class="container">
        <table class="mt-4 table table-striped table-dark">
            <thead>
            <tr>
                <th scope="col">Dni</th>
                <th scope="col">Nick</th>
                <th scope="col">nombre</th>
                <th scope="col">apellidos</th>
                <th scope="col">email</th>
                <th scope="col">password</th>
                <th scope="col">fecha_nacimiento</th>
                <th scope="col">rol</th>
            </tr>
            </thead>
            <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>

                    <th scope="row"><?php echo e($user->dni); ?></th>
                    <td><?php echo e($user->nick); ?></td>
                    <td><?php echo e($user->nombre); ?></td>
                    <td><?php echo e($user->apellidos); ?></td>
                    <td><?php echo e($user->email); ?></td>
                    <td><?php echo e($user->password); ?></td>
                    <td><?php echo e($user->fecha_nacimiento); ?></td>
                    <td><?php echo e($user->rol); ?></td>
                    <td>
                        <?php if( Auth::check() && Auth::user()->rol == 'admin'): ?>
                            <a href="<?php echo e(route('editUser',['id' => $user->dni])); ?>" class="btn btn-warning">Editar</a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </section>
    <br>
    <!-- Añadir en la tabla-->
    <section class="container">
        <h1>Añadir Usuario</h1>
        <div>
            <?php if(session('successStore')): ?>
                <div>
                    <h6 class="alert alert-success"> <?php echo e(session('successStore')); ?> </h6>
                </div>
            <?php endif; ?>
            <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><h6 class="alert alert-danger"> <?php echo e($error); ?> </h6></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>
        </div>
        <form action="<?php echo e(route('storeUser')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label for="dni">Dni</label>
                <input type="number" class="form-control" name="dni" placeholder="dni" value="<?php echo e(old('dni')); ?>">
            </div>
            <div class="form-group">
                <label for="nombre">Nombre</label>
                <input type="text" class="form-control" name="nombre" placeholder="nombre" value="<?php echo e(old('nick')); ?>">
            </div>
            <div class="form-group">
                <label for="apellido">Apellidos</label>
                <input type="text" class="form-control" name="apellidos" placeholder="Apellidos"
                       value="<?php echo e(old('apellidos')); ?>">
            </div>
            <div class="form-group">
                <label for="nick">Nick</label>
                <input type="text" class="form-control" name="nick" placeholder="nick" value="<?php echo e(old('nick')); ?>">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" value="<?php echo e(old('email')); ?>">
            </div>
            <div class="form-group">
                <label for="password">Contraseña</label>
                <input type="password" class="form-control" name="password" placeholder="Contraseña">
            </div>
            <div class="form-group">
                <label for="fecha_nacimiento">Fecha de Nacimiento</label>
                <input type="date" class="form-control" name="fecha_nacimiento" placeholder="Fecha de Nacimiento"
                       value="<?php echo e(old('fecha_nacimiento')); ?>">
            </div>
            <div class="form-group">
                <label for="rol">Rol</label>
                <select class="form-control" name="rol">
                    <option value="user" <?php echo e(old('rol') === 'user' ? 'selected' : ''); ?>>Usuario</option>
                    <option value="admin" <?php echo e(old('rol') === 'admin' ? 'selected' : ''); ?>>Administrador</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Submit</button>
        </form>
    </section>

    <br>
    <!-- Borrar de la tabla-->
    <section class="container">
        <h1>Borrar Usuario</h1>

        <?php if(session('successDestroy')): ?>
            <div class="alert alert-success">
                <?php echo e(session('successDestroy')); ?>

            </div>
        <?php endif; ?>

        <?php if(session('errorDestroy')): ?>
            <div class="alert alert-danger">
                <?php echo e(session('errorDestroy')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('destroyUser')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <div class="form-group">
                <label for="dniSolicitado">DNI a Borrar:</label>
                <input type="text" name="dniSolicitado" class="form-control" placeholder="Ingrese el DNI">
            </div>
            <button type="submit" class="btn btn-danger">Borrar</button>
        </form>
    </section>

</div>
</body>
</html>
<?php /**PATH G:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/Users/users.blade.php ENDPATH**/ ?>