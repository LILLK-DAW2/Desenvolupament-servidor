<div>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
    <script src="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script src="//cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <!------ Include the above in your HEAD tag ---------->

    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.0.8/css/all.css">


    <div class="container">
        <hr>
        <aside class="col-sm-4">
        </aside> <!-- col.// -->

        <aside class="container col-sm-4">
                <div class="card">
                    <article class="card-body">
                        <h4 class="card-title text-center mb-4 mt-1">Sign in</h4>
                        <hr>
                        <!-- Gestion de errores  -->

                        <?php if($errors->any()): ?>
                            <div class="alert alert-danger">
                                <ul>
                                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($error); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </div>
                        <?php endif; ?>
                        <?php if(session('LogError')): ?>
                            <div>
                                <h6 class="alert alert-danger"> <?php echo e(session('LogError')); ?> </h6>
                            </div>
                        <?php endif; ?>
                        <form method="POST" action="<?php echo e(route('logged')); ?>">
                            <?php echo csrf_field(); ?>
                            <!-- nick  -->
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="fa fa-user"></i> </span>
                                    </div>
                                    <input name="nick" class="form-control"    placeholder="Nick" type="text">
                                </div>
                            </div>

                            <!-- password  -->
                            <div class="form-group">
                                <div class="input-group">
                                    <div class="input-group-prepend">
                                        <span class="input-group-text"> <i class="fa fa-lock"></i> </span>
                                    </div>
                                    <input name="password" class="form-control" placeholder="Contraseña" type="password">
                                </div>
                            </div>
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary btn-block"> Login  </button>
                            </div>
                            <p class="text-center"><a href="<?php echo e(route('verReg')); ?>" class="btn">Register</a></p>
                        </form>
                    </article>
                </div>
            </aside>
        </div>
    </div>


</div>
<?php /**PATH G:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/log/login.blade.php ENDPATH**/ ?>