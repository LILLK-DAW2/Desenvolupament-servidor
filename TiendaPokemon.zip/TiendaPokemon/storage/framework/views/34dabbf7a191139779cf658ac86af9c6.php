<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<section class="container editar_carrito">
    <h1>Editar del carrito</h1>
    <?php if($errors->any()): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li><h6 class="alert alert-danger"> <?php echo e($error); ?> </h6></li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>
    <form method="POST" action="<?php echo e(route('updateCarrito')); ?>">
        <?php echo csrf_field(); ?>
        <div class="form-group">
            <label for="id">ID</label>
            <input type="text" class="form-control" name="id" value="<?php echo e($carrito->id); ?>" readonly>
        </div>
        <div class="form-group">
            <label for="id_user">Usuario:</label>
            <select name="id_user" class="form-control">
                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option  value="<?php echo e($user->dni); ?>"><?php echo e($user->nombre); ?> </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="id_pokemon">Selecciona un Pokémon:</label>
            <select name="id_pokemon" class="form-control">
                <?php $__currentLoopData = $pokemons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pokemon): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <option value="<?php echo e($pokemon->id); ?>"><?php echo e($pokemon->nombre); ?></option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
        </div>
        <div class="form-group">
            <label for="nuevaCantidad">Nueva Cantidad:</label>
            <input type="text" class="form-control" name="cantidad" value="<?php echo e($carrito->cantidad); ?>" >
        </div>
        <div class="form-group">
            <label for="nuevoPrecio">Nuevo Precio:</label>
            <input type="text" class="form-control" name="precio" value="<?php echo e($carrito->precio); ?>" >
        </div>
        <button type="submit" class="btn btn-primary">Actualizar Detalles del Carrito</button>
    </form>
</section>
<?php /**PATH G:\daw2\Desenvolupament en server\u2\PokeTienda\TiendaPokemon\resources\views/Carrito/carritoEdit.blade.php ENDPATH**/ ?>