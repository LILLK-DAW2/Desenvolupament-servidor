<?php

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Hash;

class CarritoSeeder extends Seeder
{
    public function run(): void
    {
        // Obtén los IDs de usuarios y pokémon existentes
        $userIds = DB::table('users')->pluck('dni');
        $pokemonIds = DB::table('pokemon')->pluck('id');

        // Genera datos de prueba para la tabla carrito
        for ($i = 0; $i < 10; $i++) {
            DB::table('carrito')->insert([
                'id_user' => $userIds->random(),
                'id_pokemon' => $pokemonIds->random(),
                'cantidad' => rand(1, 5),
                'precio' => rand(10, 50)
            ]);
        }
    }
}
