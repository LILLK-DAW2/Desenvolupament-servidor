<?php

namespace App\Models;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Carrito extends Model
{
    use HasFactory;

    protected $table = 'carrito'; // Nombre de la tabla en la base de datos

    protected $fillable = [
        'id_user',
        'id_pokemon',
        'cantidad',
        'precio',
    ];
    public $timestamps = false;


    // Relación con la tabla 'users'
    public function user()
    {
        return $this->belongsTo(User::class, 'id_user', 'dni');
    }

    // Relación con la tabla 'pokemon'
    public function pokemon()
    {
        return $this->belongsTo(Pokemon::class, 'id_pokemon', 'id');
    }}
