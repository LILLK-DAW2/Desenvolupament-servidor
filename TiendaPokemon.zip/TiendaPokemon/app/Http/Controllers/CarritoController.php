<?php

namespace App\Http\Controllers;

use App\Models\Carrito;
use App\Models\Pokemon;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class CarritoController extends Controller
{
    public function index()
    {
        $idUser = Auth::id();

        //dd($productosUsuario);
        //si el usuario es admin podra ver toda la tabla
        if (Auth::user()->rol == 'admin') {
            $carrito = Carrito::all();
        } else {
            //sino solo sus productos
            $carrito = Carrito::where('id_user', $idUser)->get();
        }
        $users = User::all();
        $pokemons = Pokemon::all();
        return view('Carrito.carrito')->with(['carrito' => $carrito, 'users' => $users, 'pokemons' => $pokemons]);
    }

    public function store(Request $request)
    {
        $request->validate([
            'id_pokemon' => 'required|exists:pokemon,id',
            'id_user' => 'required|exists:users,dni',
            'cantidad' => 'required|integer|min:1',
            'precio' => 'required|integer|min:1',

        ]);
        // dd($request);
        // Crear el registro en la tabla carrito
        Carrito::create([
            'id_user' => $request->id_user,
            'id_pokemon' => $request->id_pokemon,
            'cantidad' => $request->cantidad,
            'precio' => $request->precio,
        ]);

        return redirect()->back()->with('succes', 'Pokémon añadido al carrito exitosamente.');
    }

    public function destroy(Request $request)
    {
        //dd($request);
        // Obtener el ID del Pokémon a eliminar desde la solicitud HTTP
        $idSolicitado = $request->input('idSolicitado');

        try {
            // Buscar el Pokémon por su ID en la base de datos
            $carrito = Carrito::findOrFail($idSolicitado);

            // Eliminar el Pokémon
            $carrito->delete();

            // Redirigir a la vista de Pokémon con un mensaje de éxito
            return redirect()->back()->with('succesDestroy', 'Carrito eliminado correctamente');
        } catch (\Exception $e) {
            // En caso de error, redirigir a la vista de Pokémon con un mensaje de error
            return redirect()->back()->with('errorDestroy', 'Error al intentar eliminar el carrito');
        }
    }

    public function agregar(Request $request)
    {
        //dd($request);

        $request->validate([
            'id_pokemon' => 'required|exists:pokemon,id',
        ]);
        $user = Auth::user();
        $pokemon = Pokemon::findOrFail($request->id_pokemon);

        // Verificar si hay suficiente stock para agregar a la cantidad solicitada
        if ($pokemon->stock < 1) {
            return redirect()->back()->with('error', 'No hay suficiente stock disponible.');
        }


        // Verificar si el Pokémon ya está en el carrito
        $carritoExistente = Carrito::where([
            'id_user' => $user->dni,
            'id_pokemon' => $request->id_pokemon
        ])->first();

        if ($carritoExistente) {
            // Incrementar la cantidad y precio si el Pokémon ya está en el carrito
            $carritoExistente->cantidad++;
            $carritoExistente->precio += $pokemon->precio;
            $carritoExistente->save();

        } else {
            // Crear un nuevo registro en el carrito si el Pokémon no está en el carrito
            Carrito::create([
                'id_user' => $user->dni,
                'id_pokemon' => $request->id_pokemon,
                'cantidad' => 1,
                'precio' => $pokemon->precio,
            ]);
        }
        // Restar el stock del Pokémon
        $pokemon->stock--;
        $pokemon->save();
        return redirect()->back()->with('succes', 'Pokémon añadido al carrito exitosamente.');
    }

    public function retirar(Request $request)
    {
        //dd($request);
        $request->validate([
            'id_pokemon' => 'required|exists:pokemon,id',
            'id_user' => 'required|exists:users,dni',
        ]);

        $pokemon = Pokemon::findOrFail($request->id_pokemon);

        // Buscar y eliminar el Pokémon del carrito
        $carritoExistente = Carrito::where([
            'id_user' => $request->id_user,
            'id_pokemon' => $request->id_pokemon
        ])->first();
        if ($carritoExistente) {
            // Restar la cantidad del carrito y actualizar el precio total
            $carritoExistente->cantidad--;

            // Verificar si la cantidad llega a cero para eliminar el registro del carrito
            if ($carritoExistente->cantidad == 0) {
                $carritoExistente->delete();
            } else {
                // Actualizar el precio total al restar un Pokémon del carrito
                $carritoExistente->precio -= $pokemon->precio;
                $carritoExistente->save();
            }

            // Incrementar el stock del Pokémon
            $pokemon->stock++;
            $pokemon->save();

            return redirect()->back()->with('succes', 'Pokémon retirado del carrito exitosamente.');
        }

        return redirect()->back()->with('error', 'El Pokémon no se encuentra en el carrito.');
    }

    public function edit($id)
    {
        $carrito = Carrito::findOrFail($id);
        $users = User::all();
        $pokemons = Pokemon::all();
        return view('Carrito.carritoEdit')->with(['carrito' => $carrito, 'users' => $users, 'pokemons' => $pokemons]);
    }

    public function update (Request $request)
    {

        $id = $request->input('id');
        $carrito = Carrito::findOrFail($id);
        //dd($request);

        $request->validate([
            'id_pokemon' => 'required|exists:pokemon,id',
            'id_user' => 'required|exists:users,dni',
        ]);

        $carrito->update($request->all());
        //dd($carrito);
        return redirect()->route('verCarrito')->with('succes', 'carrito editado exitosamente.');
    }

}
