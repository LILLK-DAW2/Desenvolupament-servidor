<?php
namespace App\Http\Controllers;

use App\Models\Pokemon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Validation\Rule;


class PokemonController extends Controller
{

    /**
     * Display a listing of the resource.
     */
    public function index()
    {

        $pokemons = Pokemon::all();
        return view('Tienda.pokemons')->with('pokemons', $pokemons);
    }
    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $tiposPermitidos = ['eléctrico', 'bicho', 'fuego', 'agua', 'planta', 'roca', 'hielo', 'veneno', 'volador'];
        $this->validate($request, [
            'nombre' => 'required|string|max:30',
            'tipo' => [
                'required',
                'string',
                'max:20',
                Rule::in($tiposPermitidos),
            ],
            'nivel' => 'integer|required',
            'descripcion' => 'nullable|string',
            'stock' => 'integer|required',
            'precio' => 'numeric|required',
        ]);
        Pokemon::create($request->all());
        return redirect()->route('verPokemons')->with('successStore','Pokemon creado correctamente');
    }

    /**
     * Elimina un Pokémon específico.
     */
    public function destroy(Request $request)

    {
        //dd($request);
        // Obtener el ID del Pokémon a eliminar desde la solicitud HTTP
        $idSolicitado = $request->input('idSolicitado');

        try {
            // Buscar el Pokémon por su ID en la base de datos
            $pokemon = Pokemon::findOrFail($idSolicitado);

            // Eliminar el Pokémon
            $pokemon->delete();

            // Redirigir a la vista de Pokémon con un mensaje de éxito
            return redirect()->route('verPokemons')->with('successDestroy', 'Pokemon eliminado correctamente');
        } catch (\Exception $e) {
            // En caso de error, redirigir a la vista de Pokémon con un mensaje de error
            return redirect()->route('verPokemons')->with('errorDestroy', 'Error al intentar eliminar el Pokémon');
        }
    }

    public function edit($id)
    {
        $pokemon = Pokemon::findOrFail($id);
        return view('Tienda.pokemonsEdit')->with('pokemon', $pokemon);
    }

    public function update(Request $request)

    {
        $id = $request->input('id');
        $pokemon = Pokemon::findOrFail($id);

        $tiposPermitidos = ['eléctrico', 'bicho', 'fuego', 'agua', 'planta', 'roca', 'hielo', 'veneno', 'volador'];
        $request->validate([
            'nombre' => 'required|string|max:30',
            'tipo' => [
                'required',
                'string',
                'max:20',
                Rule::in($tiposPermitidos),
            ],
            'nivel' => 'integer|nullable',
            'descripcion' => 'nullable|string',
            'stock' => 'integer|nullable',
            'precio' => 'numeric|nullable',
        ]);

        $pokemon->update($request->all());

        return redirect()->route('verPokemons')->with('successUpdate', 'Pokemon actualizado correctamente');
    }
}
