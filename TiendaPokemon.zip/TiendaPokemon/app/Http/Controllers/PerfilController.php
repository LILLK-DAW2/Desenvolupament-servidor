<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;

class PerfilController extends Controller
{
    public function index()
    {
        $user = User::findOrFail(Auth::user()->dni);

        return view('Perfil.perfil')->with('user', $user);
    }

    public function update(Request $request)

    {
        //dd($request);
        $user = User::findOrFail(Auth::user()->dni);
        //dd($user);
        $request->validate([
            'email' => 'required|email',
            'nick' => 'required|string|max:20',

        ]);
        $user->update([
            'email' => $request->input('email'),
            'nick' => $request->input('nick'),
        ]);
        //dd($user);
        return redirect()->route('verPerfil')->with('successUpdate', 'Perfil actualizado correctamente');
    }
}
