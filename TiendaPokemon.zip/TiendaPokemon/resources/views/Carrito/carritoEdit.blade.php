<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css" integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">
<section class="container editar_carrito">
    <h1>Editar del carrito</h1>
    @if ($errors->any())
        <div class="alert alert-danger">
            <ul>
                @foreach ($errors->all() as $error)
                    <li><h6 class="alert alert-danger"> {{ $error }} </h6></li>
                @endforeach
            </ul>
        </div>
    @endif
    <form method="POST" action="{{ route('updateCarrito') }}">
        @csrf
        <div class="form-group">
            <label for="id">ID</label>
            <input type="text" class="form-control" name="id" value="{{ $carrito->id }}" readonly>
        </div>
        <div class="form-group">
            <label for="id_user">Usuario:</label>
            <select name="id_user" class="form-control">
                @foreach($users as $user)
                    <option  value="{{ $user->dni }}">{{ $user->nombre }} </option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="id_pokemon">Selecciona un Pokémon:</label>
            <select name="id_pokemon" class="form-control">
                @foreach($pokemons as $pokemon)
                    <option value="{{ $pokemon->id }}">{{ $pokemon->nombre }}</option>
                @endforeach
            </select>
        </div>
        <div class="form-group">
            <label for="nuevaCantidad">Nueva Cantidad:</label>
            <input type="text" class="form-control" name="cantidad" value="{{ $carrito->cantidad }}" >
        </div>
        <div class="form-group">
            <label for="nuevoPrecio">Nuevo Precio:</label>
            <input type="text" class="form-control" name="precio" value="{{ $carrito->precio }}" >
        </div>
        <button type="submit" class="btn btn-primary">Actualizar Detalles del Carrito</button>
    </form>
</section>
