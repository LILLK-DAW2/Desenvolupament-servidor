<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.4.1/dist/css/bootstrap.min.css"
          integrity="sha384-Vkoo8x4CGsO3+Hhxv8T/Q5PaXtkKtu6ug5TOeNV6gBiFeWPGFN9MuhOf23Q9Ifjh" crossorigin="anonymous">

    <title>Carrito</title>
</head>
<body>
<!-- Navbar -->
<div>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav">
                <li class="nav-item active">
                    <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="{{ route('verPokemons') }}">Tienda<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="{{ route('verPerfil') }}">Perfil<span class="sr-only">(current)</span></a>
                </li>
                @if(Auth::check() && Auth::user()->rol == 'admin')
                    <li class="nav-item active">
                        <a class="nav-link link-warning" href="{{ route('verUsers') }}">Usuarios<span class="sr-only">(current)</span></a>
                    </li>
                @endif
                <li class="nav-item active">
                    <a class="btn btn-warning" href="{{ route('logout') }}">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
</div>

<!-- Vista de la tabla carrito -->
<div class="container mt-4">
    <section class="container ver_carrito">
        @if(session('succes'))
            <h6 class="alert alert-success"> {{ session('succes') }} </h6>
        @elseif(session('error'))
            <h6 class="alert alert-danger"> {{ session('error') }} </h6>
        @endif
        @if(session('successUpdate'))
            <div>
                <h6 class="alert alert-success"> {{session('successUpdate')}} </h6>
            </div>
        @endif
        <table class="mt-4 table table-striped table-dark">
            <thead>
            <tr>
                <th scope="col">#</th>
                @if( Auth::check() && Auth::user()->rol == 'admin')
                    <th scope="col">Usuario</th>
                @endif
                <th scope="col">Pokemon</th>
                <th scope="col">Cantidad</th>
                <th scope="col">Precio Total</th>
            </tr>
            </thead>
            <tbody>
            @foreach($carrito as $item)
                <tr>
                    <th scope="row">{{ $item->id }}</th>
                    @if( Auth::check() && Auth::user()->rol == 'admin')
                        <td>{{ $item->user->nombre }}</td>
                    @endif
                    <td>{{ $item->pokemon->nombre }}</td>
                    <td>{{ $item->cantidad }}</td>
                    <td>{{ $item->precio }} $</td>
                    <td>
                        <a href="{{route('addCarrito',['id_pokemon' => $item->pokemon->id ,'id_user' => $item->user->dni])}}" class="btn btn-warning"><i class="bi bi-plus">+</i></a>
                        <a href="{{route('restCarrito',['id_pokemon' => $item->pokemon->id , 'id_user' => $item->user->dni])}}" class="btn btn-warning"><i class="bi bi-dash"> - </i></a>
                        @if( Auth::check() && Auth::user()->rol == 'admin')
                            <a href="{{route('editCarrito' , ['id' => $item->id])}}" class="btn btn-warning"><i class="bi bi-dash">Editar</i></a>
                        @endif
                    </td>
                </tr>
            @endforeach
            </tbody>
        </table>
    </section>
    <br>
    <!-- Añadir al carrito -->
    <section class="container">
        <h1>Añadir al carrito</h1>
        @if(session('succes'))
            <div>
                <h6 class="alert alert-success"> {{session('succes')}} </h6>
            </div>
        @endif
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li><h6 class="alert alert-danger"> {{ $error }} </h6></li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form action="{{route('storeCarrito')}}" method="POST">
            @csrf
            <div class="form-group">
                <label for="id_user">Usuario:</label>
                <select name="id_user" class="form-control">
                    @foreach($users as $user)
                        <option value="{{$user->dni}}">{{ $user->nombre }}</option>
                    @endforeach
                </select>
            </div>
            <div class="form-group">
                <label for="id_pokemon">Selecciona un Pokémon:</label>
                <select name="id_pokemon" class="form-control">
                    @foreach($pokemons as $pokemon)
                        <option value="{{ $pokemon->id }}">{{ $pokemon->nombre }}</option>
                    @endforeach
                </select>
            </div>

            <div class="form-group">
                <label for="cantidad">Cantidad:</label>
                <input type="number" name="cantidad" class="form-control" placeholder="cantidad">
            </div>
            <div class="form-group">
                <label for="precio">Precio:</label>
                <input type="text" name="precio" class="form-control" placeholder="precio">
            </div>
            <button type="submit" class="btn btn-primary">Añadir al carrito</button>
        </form>
    </section>
    <br>
    <!-- Borrar del carrito -->
    <section class="container borrar_carrito">
        <h1>Borrar del carrito</h1>
        @if(session('succesDestroy'))
            <div class="alert alert-success">
                {{ session('succesDestroy') }}
            </div>
        @endif

        @if(session('errorDestroy'))
            <div class="alert alert-danger">
                {{ session('errorDestroy') }}
            </div>
        @endif
        <form method="POST" action="{{ route('destroyCarrito') }}">
            @csrf
            @method('delete')
            <div class="form-group">
                <label for="idSolicitado">ID del Pokémon en el carrito:</label>
                <input type="text" name="idSolicitado" class="form-control" placeholder="Ingrese el ID">
            </div>
            <button type="submit" class="btn btn-danger">Borrar del carrito</button>
        </form>
    </section>
</div>
</body>
</html>
