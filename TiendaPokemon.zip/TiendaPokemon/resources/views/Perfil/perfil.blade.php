<div>
    <link href="//maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">

    <nav class="navbar navbar-expand-lg  navbar-dark bg-dark">
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav ">
                <li class="nav-item active">
                    <a class="nav-link" href="/home">Home<span class="sr-only">(current)</span></a>
                </li>
                <li class="nav-item active">
                    <a class="nav-link" href="/pokemons">Tienda<span class="sr-only">(current)</span></a>
                </li>

                <li class="nav-item active">
                    <a class="nav-link" href="{{route('verCarrito')}}">Carrito<span class="sr-only">(current)</span></a>
                </li>

                @if( Auth::check() && Auth::user()->rol == 'admin')

                    <li class="nav-item active">
                        <a class="nav-link link-warning" href="{{route('verUsers')}}">Usuarios <span class="sr-only">(current)</span></a>
                    </li>
                @endif

                <li class="nav-item active">
                    <a class="btn btn-warning"  href="{{route('logout')}}">Log out<span class="sr-only">(current)</span></a>
                </li>
            </ul>
        </div>
    </nav>
    <section class="container">
        <h1>Editar Usuario</h1>
        @if(session('successUpdate'))
            <div>
                <h6 class="alert alert-success"> {{session('successUpdate')}} </h6>
            </div>
        @endif
        @if ($errors->any())
            <div class="alert alert-danger">
                <ul>
                    @foreach ($errors->all() as $error)
                        <li><h6 class="alert alert-danger"> {{ $error }} </h6></li>
                    @endforeach
                </ul>
            </div>
        @endif
        <form action="{{ route('updatePerfil') }}" method="POST">
            @csrf
            @method('POST')
            <!-- Campo no editable para el DNI -->
            <div class="form-group">
                <label for="nick">Nick</label>
                <input type="text" class="form-control" name="nick" placeholder="nick" value="{{ $user->nick }}">
            </div>
            <div class="form-group">
                <label for="email">Email</label>
                <input type="email" class="form-control" name="email" placeholder="Email" value="{{ $user->email }}">
            </div>

            <button type="submit" class="btn btn-primary">Guardar cambios</button>
        </form>
    </section>

</div>
